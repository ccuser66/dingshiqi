#include "hello.h"
int main()
{
hello("everyone");
return 0;
}
