#include <stdio.h>
void hello(const char *name)
{
printf("Hello %s!\n", name);
}
