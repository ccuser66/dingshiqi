#include<stdio.h>
float x2y(int a, int b)
{
	float z;
	z = a + b;
	return z;
}
