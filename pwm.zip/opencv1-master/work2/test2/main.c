#include<stdio.h>
int main()
{
	int x, y;
	x = 3; y = 6;
	float k,h;
	k = x2x(x, y);
	h =x2y(x,y);
	printf("%f\n", k);
	printf("%f\n", h);
	return 0;
}


