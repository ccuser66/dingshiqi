#include<stdio.h>
float x2x(int a, int b)
{
	float z;
	z = a * b;
	return z;
}
