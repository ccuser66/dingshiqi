#include <stdio.h>
//此程序很简单，仅仅打印一个 Hello World 的字符串。
int main(void)
{
printf("Hello World! \n");
return 0;
}
